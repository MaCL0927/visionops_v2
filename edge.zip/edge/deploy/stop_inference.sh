#!/usr/bin/env bash
set -euo pipefail

PORT="${1:-8082}"
SERVICE_NAME="${2:-visionops-inference}"

echo "[INFO] stopping service: ${SERVICE_NAME}"
sudo systemctl stop "${SERVICE_NAME}" 2>/dev/null || true

echo "[INFO] killing old engine.py processes"
sudo pkill -9 -f "/opt/visionops/edge/inference/engine.py" 2>/dev/null || true
sudo pkill -9 -f "edge/inference/engine.py" 2>/dev/null || true

echo "[INFO] freeing port: ${PORT}"
sudo fuser -k "${PORT}/tcp" 2>/dev/null || true

sleep 1

if ss -lntp 2>/dev/null | grep -q ":${PORT}"; then
  echo "[ERROR] port ${PORT} is still occupied:"
  ss -lntp | grep ":${PORT}" || true
  exit 1
fi

echo "[OK] inference stopped and port ${PORT} is free"